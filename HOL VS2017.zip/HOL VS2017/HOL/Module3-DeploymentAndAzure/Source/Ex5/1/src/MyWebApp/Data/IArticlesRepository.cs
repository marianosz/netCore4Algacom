using ConsoleApplication.Entities;

namespace ConsoleApplication.Data
{
    public interface IArticlesRepository : IRepository<Article> { }
}