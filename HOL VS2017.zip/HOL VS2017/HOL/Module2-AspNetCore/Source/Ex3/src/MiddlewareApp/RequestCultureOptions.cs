﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace MiddlewareApp
{
    public class RequestCultureOptions
    {
        public CultureInfo DefaultCulture { get; set; }
    }
}
