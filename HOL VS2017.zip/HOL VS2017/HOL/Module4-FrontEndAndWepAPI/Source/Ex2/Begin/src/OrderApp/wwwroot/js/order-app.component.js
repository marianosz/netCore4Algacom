System.register(["angular2/core", "ag-grid-ng2/main", "./refData", "./details-grid.component", "./order.service"], function (exports_1, context_1) {
    "use strict";
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var __moduleName = context_1 && context_1.id;
    var core_1, main_1, refData_1, details_grid_component_1, order_service_1, OrderApp, OrderApp_1;
    return {
        setters: [
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (main_1_1) {
                main_1 = main_1_1;
            },
            function (refData_1_1) {
                refData_1 = refData_1_1;
            },
            function (details_grid_component_1_1) {
                details_grid_component_1 = details_grid_component_1_1;
            },
            function (order_service_1_1) {
                order_service_1 = order_service_1_1;
            }
        ],
        execute: function () {
            OrderApp = OrderApp_1 = (function () {
                function OrderApp(_orderService) {
                    this._orderService = _orderService;
                    // we pass an empty gridOptions in, so we can grab the api out
                    this.gridOptions = {};
                    this.createColumnDefs();
                }
                OrderApp.prototype.ngOnInit = function () {
                    this.loadData();
                };
                OrderApp.prototype.loadData = function () {
                    var _this = this;
                    this._orderService.getOrders()
                        .then(function (orders) { return _this.rowData = orders; });
                };
                OrderApp.prototype.createColumnDefs = function () {
                    this.columnDefs = [
                        {
                            headerName: "Order",
                            children: [
                                {
                                    headerName: "ID", field: "id",
                                    width: 30, pinned: true
                                },
                                {
                                    headerName: "Date", field: "date",
                                    width: 80, pinned: true
                                },
                                {
                                    headerName: "Total", field: "orderTotal",
                                    width: 80,
                                    cellRenderer: function (params) {
                                        return "$" + params.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
                                    }, pinned: true
                                },
                            ]
                        },
                        {
                            headerName: "Customer",
                            children: [
                                {
                                    headerName: "Name", field: "name",
                                    width: 150, pinned: true
                                },
                                {
                                    headerName: "Country", field: "country", width: 150,
                                    cellRenderer: OrderApp_1.countryCellRenderer, pinned: true,
                                    filterParams: { cellRenderer: OrderApp_1.countryCellRenderer, cellHeight: 20 }
                                },
                            ]
                        },
                        {
                            headerName: "Contact",
                            children: [
                                { headerName: "Phone", field: "phone", width: 150, filter: "text" },
                                { headerName: "Address", field: "address", width: 500, filter: "text" }
                            ]
                        }
                    ];
                };
                OrderApp.prototype.calculateRowCount = function () {
                    if (this.rowData) {
                        this.rowCount = this.rowData.length.toLocaleString();
                    }
                };
                OrderApp.prototype.onModelUpdated = function () {
                    this.calculateRowCount();
                };
                OrderApp.prototype.onReady = function () {
                    this.calculateRowCount();
                };
                OrderApp.prototype.onRowClicked = function ($event) {
                    this.selectedItem = $event.node.data;
                };
                OrderApp.prototype.onQuickFilterChanged = function ($event) {
                    this.gridOptions.api.setQuickFilter($event.target.value);
                };
                OrderApp.prototype.updateOrderTotal = function ($event) {
                    var id = this.selectedItem.id;
                    var updatedNodes = [];
                    this.gridOptions.api.forEachNode(function (node) {
                        var data = node.data;
                        if (data.id === id) {
                            data.orderTotal = $event;
                            updatedNodes.push(node);
                        }
                    });
                    this.gridOptions.api.refreshCells(updatedNodes, ["orderTotal"]);
                };
                OrderApp.countryCellRenderer = function (params) {
                    var flag = "<img border='0' width='15' height='10' style='margin-bottom: 2px' src='../images/flags/" +
                        refData_1.default.COUNTRY_CODES[params.value] + ".png'>";
                    return flag + " " + params.value;
                };
                return OrderApp;
            }());
            OrderApp = OrderApp_1 = __decorate([
                core_1.Component({
                    selector: "order-app",
                    providers: [order_service_1.OrderService],
                    directives: [main_1.AgGridNg2, details_grid_component_1.DetailsGridComponent],
                    templateUrl: "../html/order-app.html"
                }),
                __metadata("design:paramtypes", [order_service_1.OrderService])
            ], OrderApp);
            exports_1("OrderApp", OrderApp);
        }
    };
});
//# sourceMappingURL=order-app.component.js.map